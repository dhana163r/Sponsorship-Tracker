package com.sponsortracker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // keeps sponsor data saved in the app
        s.setAllowFileAccess(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        // Lets the page hand Excel/PDF files to the Android share sheet (Save to Drive/Files, WhatsApp, email...)
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void share(final String name, final String mime, final String b64, final String via) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                            File dir = new File(getCacheDir(), "exports");
                            dir.mkdirs();
                            File f = new File(dir, name.replaceAll("[^A-Za-z0-9._-]", "_"));
                            FileOutputStream o = new FileOutputStream(f);
                            o.write(bytes);
                            o.close();
                            Uri u = FileProvider.getUriForFile(MainActivity.this,
                                    getPackageName() + ".fileprovider", f);
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType(mime);
                            i.putExtra(Intent.EXTRA_STREAM, u);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            if ("whatsapp".equals(via)) {
                                Intent t = new Intent(i);
                                t.setPackage("com.whatsapp");
                                try { startActivity(t); return; } catch (Exception ex) {
                                    Toast.makeText(MainActivity.this, "WhatsApp not found, choose another app", Toast.LENGTH_LONG).show();
                                }
                            } else if ("email".equals(via)) {
                                Intent t = new Intent(i);
                                t.putExtra(Intent.EXTRA_SUBJECT, "Sponsor tracker report");
                                t.setSelector(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")));
                                try { startActivity(t); return; } catch (Exception ex) {
                                    Toast.makeText(MainActivity.this, "No email app found, choose another app", Toast.LENGTH_LONG).show();
                                }
                            }
                            startActivity(Intent.createChooser(i, "Share or save " + name));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Could not create the file", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }, "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
        }
        super.onActivityResult(req, res, data);
    }
}
