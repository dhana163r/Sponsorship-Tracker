# Sponsor Tracker (Android)

Wraps the sponsor tracker web page in a WebView. All data stays on the phone.

## Build the APK
1. Install Android Studio (free) and open this folder (File > Open).
2. Let it sync (it downloads Gradle and the Android SDK 34 if asked).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find app-debug.apk in app/build/outputs/apk/debug/, copy it to the phone, tap it to install (allow "install unknown apps" if asked).

## Edit the app
The whole interface is app/src/main/assets/index.html.

## Notes
- Data is stored inside this app, separate from the Chrome version.
- Photo/cheque upload opens the phone's file or photo picker.
- For Play Store release, create a signed bundle: Build > Generate Signed Bundle / APK.
- Export / Share creates Excel and PDF files and opens the Android share sheet (save to Drive or Files, WhatsApp, email). It needs an internet connection the first time so the Excel and PDF libraries can load.
- In the Export / Share box, "Send via" can open WhatsApp or your email app directly with the file attached.

## Get the APK without Android Studio (GitHub)
1. Create a free account at github.com and a new repository.
2. Upload all files of this folder to it (keep the .github folder).
3. Open the Actions tab, run "Build APK" (it also runs on every upload).
4. When it finishes, open the run and download the SponsorTracker-apk file. Unzip it to get app-debug.apk and install it on the phone.
